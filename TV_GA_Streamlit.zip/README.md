# TV Scheduling Optimizer — Genetic Algorithm

Streamlit application for JIE42903 Evolutionary Computing assignment.

## Files
- `app.py`: Streamlit interface, schedule display, saved trial comparison and rating changes.
- `ga_engine.py`: Genetic Algorithm implementation.
- `program_ratings_modified.csv`: dataset used for optimization.
- `program_ratings_original.csv`: reference for before/after modification table.
- `requirements.txt`: deployment dependencies.

## Deployment (GitHub + Streamlit Community Cloud)
Upload all five files to the **root** of the existing GitHub repository, replacing the earlier versions of `app.py` and README. Select branch `main` and main file `app.py` in Streamlit Cloud. If the app is already deployed, pushing the changes should trigger a redeploy.

## Experiments
Recommended trial configurations: (CO_R, MUT_R) = (0.40, 0.01), (0.70, 0.03), (0.95, 0.05). Keep population=50, generations=100 and seed=42 for a controlled first comparison. Save each trial; download individual schedules and the comparison CSV. Repeat with multiple seeds for stronger conclusions.

## Model notes
- 18 hourly slots, 10 possible program categories; repetition allowed.
- Fitness is sum of selected program ratings.
- Tournament selection, single-point crossover, mutation of one gene per selected offspring, elitism of 2.
- Theoretical upper bound assumes no constraints beyond a program choice for each time slot.
- **Assignment ambiguity:** MUT_R default 0.20 conflicts with stated range 0.01–0.05. Default 0.20 is retained, but the interface permits the experiment range. Confirm with lecturer.
- Check whether these GA operators match the exact Week 4 tutorial before claiming strict equivalence.

## Visual theme
Rose & Burgundy: warm rose accents, burgundy header, blush panels and readable light background. Streamlit theme is configured in `.streamlit/config.toml`.
